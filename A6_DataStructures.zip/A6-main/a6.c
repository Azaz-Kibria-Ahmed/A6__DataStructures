#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

long getIDX(char *base, char *val)
{
    char idxname[BUFFER];
    char txtname[BUFFER];

    long hash_table[HASHSIZE];

    // identify text file name
    strcpy(idxname, base);
    strcat(idxname, ".idx");
    strcpy(txtname, base);
    strcat(txtname, ".txt");

    // target value

    // load hashtable from file into memory
    get_hashtable(base, hash_table);

    // open text file
    FILE *idxfile = fopen(idxname, "r");
    FILE *txtfile = fopen(txtname, "r");
    long index = hash_lookup(val, hash_table, idxfile, txtfile);

    fclose(idxfile);
    fclose(txtfile);
    return index;
}
int entries(char *filebase)
{
    char filename[BUFFER];
    int ent;

    strcpy(filename, filebase);
    strcat(filename, ".idx");
    FILE *fp = fopen(filename, "rb");
    fseek(fp, 0, SEEK_END);
    ent = ftell(fp) / sizeof(long);
    fclose(fp);

    return ent;
}

void query(int code, char *base, int index, char *fileOut)
{

    char *v1 = "code";
    int i1 = code;
    char *v2 = base;
    int i2 = index;
    int n1 = entries(v1);
    int n2 = entries(v2);

    char filename[BUFFER];

    strcpy(filename, v1);
    strcat(filename, "_");
    strcat(filename, v2);
    strcat(filename, ".rel");

    FILE *fp = fopen(filename, "rb");
    char *array = malloc(n1 * n2);
    fread(array, 1, n1 * n2, fp);
    fclose(fp);

    fp = fopen(fileOut, "wb");
    if ((i1 == -1) && (i2 >= 0))
    {
        for (int i = 0; i < n1; i++)
        {
            int index = i * n2 + i2;
            fwrite(array + index, 1, 1, fp);
        }
    }

    if ((i1 > 0) && (i2 == -1))
    {
        for (int j = 0; j < n2; j++)
        {
            int index = i1 * n2 + j;
            fwrite(array + index, 1, 1, fp);
        }
    }

    fclose(fp);
}

void intersect(char *file1, char *file2, char *fileOut)
{
    FILE *fp1 = fopen(file1, "rb");
    FILE *fp2 = fopen(file2, "rb");
    FILE *fp3 = fopen(fileOut, "wb");
    char b1, b2, b3;

    while (fread(&b1, 1, 1, fp1) == 1 && fread(&b2, 1, 1, fp2))
    {
        b3 = b1 && b2;
        fwrite(&b3, 1, 1, fp3);
    }

    fclose(fp1);
    fclose(fp2);
    fclose(fp3);
}

int *set2IDX(char *setFile)
{
    char boolean;
    int count = 0;

    int *array = malloc(sizeof(int));
    array[0]=-1;

    FILE *fp = fopen(setFile, "rb");

    for (int i = 0; fread(&boolean, 1, 1, fp) == 1; i++)
    {
        if (boolean)
        {
            array = realloc(array, sizeof(int) * (i + 2));
            array[count] = i;
            array[count + 1] = -1;
            //printf("%d\n", i);
            count++;
        }
    }
    fclose(fp);

    return array;
}

char *getString(char *base, int index)
{
    char *basename;
    int idx, idx2;
    basename = base;
    idx = index;

    char txtfile[BUFFER];
    char idxfile[BUFFER];
    char * buffer = malloc(sizeof(char)*BUFFER);

    FILE *fptxt, *fpidx;

    strcpy(txtfile, basename);
    strcat(txtfile, ".txt");

    strcpy(idxfile, basename);
    strcat(idxfile, ".idx");

    fptxt = fopen(txtfile, "r");
    fpidx = fopen(idxfile, "r");

    fseek(fpidx, sizeof(long) * idx, SEEK_SET);

    if (fread(&idx2, sizeof(long), 1, fpidx) != 1)
    {
        fprintf(stderr, "Error: invalid index\n");
        exit(-1);
    }

    fclose(fpidx);

    fseek(fptxt, idx2, SEEK_SET);
    fgets(buffer, BUFFER, fptxt);

    int i=0;

    for(i=0;i<BUFFER;i++){
        if(buffer[i]=='\n'){
            buffer[i]='\0';
            break;
        }
    }

    //printf("%s\n", buffer);
    fclose(fptxt);
    return buffer;
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <building> <room>\n", argv[0]);
        exit(-1);
    }

    // buidingID =  ./getidx buidling argv[1]
    long buildingIndex = getIDX("building", argv[1]);

    //printf("building %ld\n", buildingIndex);

    // roomID = ./getidx room argv[2]
    long roomIndex = getIDX("room", argv[2]);

    //printf("room %ld\n", roomIndex);
    // return 0;
    //setBuildingID =  ./query code -1 building $buildingID building_3.set

    query(-1, "building", buildingIndex, "buildingQRes.set");

    //setRoomID =  ./query code -1 building $roomID room_49.set

    query(-1, "room", roomIndex, "roomQRes.set");

    // intersect = ./and setBuildingID, setRoomID

    intersect("buildingQRes.set", "roomQRes.set", "intersect.set");

    //  ./set2idx intersect returns codes for all subject in that room

    int *array = set2IDX("intersect.set");

    //  loop over all subject codes
    int i = 0;
    while (array[i] != -1)
    {
        //printf("[%d]  %d\n", i,array[i]);

        //query subject
        query(array[i], "subject", -1, "subject.set");
        int *subjectSet = set2IDX("subject.set");
        char * subject = getString("subject",subjectSet[0]);
        //query course
        query(array[i], "courseno", -1, "courseno.set");
        int *courseNoSet = set2IDX("courseno.set");
        char * courseno = getString("courseno",courseNoSet[0]);
        //query days
        query(array[i], "days", -1, "days.set");
        int *daysSet = set2IDX("days.set");
        char * days = getString("days",daysSet[0]);

        //query from
        query(array[i], "from", -1, "from.set");
        int *fromSet = set2IDX("from.set");
        char * from = getString("from",fromSet[0]);

        //query to
        query(array[i], "to", -1, "to.set");
        int *toSet = set2IDX("to.set");
        char * to = getString("to",toSet[0]);

        printf("%s*%s %s %s - %s\n", subject, courseno, days, from, to); 
        free(subjectSet);
        free(subject);
        free(courseNoSet);
        free(courseno);
        free(daysSet);
        free(days);
        free(fromSet);
        free(from);
        free(toSet);
        free(to);

        i++;

    }

    free(array);

    return 0;
}

